﻿using System;
namespace CarDealer.DTO
{
    public class PartsOfCarsDTO
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}
