﻿using System;
using System.Collections.Generic;

namespace ProductShop.DTO
{
    public class SoldProducts
    {
        public SoldProducts()
        {
            this.Products = new List<ProductsDto>();
        }

        public int Count { get => this.Products.Count; }

        public List<ProductsDto> Products { get; set; }
    }

}
