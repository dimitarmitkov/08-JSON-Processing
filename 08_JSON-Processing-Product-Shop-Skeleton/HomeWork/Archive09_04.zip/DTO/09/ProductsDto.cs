﻿using System;
namespace ProductShop.DTO
{
    public class ProductsDto
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }

}
