﻿namespace ProductShop.DTO.User
{
    using Newtonsoft.Json;

    public class ProductSoldUserCountDTO
    {
        [JsonProperty("count")]
        public int Count { get; set; }

        [JsonProperty("products")]
        public ProductSoldUserDTO[] Products { get; set; }
    }
}
